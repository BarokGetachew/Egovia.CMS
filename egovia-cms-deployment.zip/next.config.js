/** @type {import('next').NextConfig} */
const nextConfig = {
  sassOptions: {
    includePaths: ['node_modules'],
  },
}

module.exports = nextConfig
